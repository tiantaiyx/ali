{
  "author":"20220530",
  "name": "打驴动漫",
  "url": "https://www.dqsj.cc", //填网站链接
  "tihuan": "cnzz.com", //这个不用动，是个别网站嗅探时过滤地址用的
  "User": "空", //这个不用动，是个别网站播放需要请求头时才用到
  "shouye": "1",
  "fenlei": "热门新番$/index.php/vod/show/id/23/page/#日本动漫$/index.php/vod/show/id/21/page/#国产动漫$/index.php/vod/show/id/22/page/#欧美动漫$/index.php/vod/show/id/25/page/#动漫电影$/index.php/vod/show/id/24/page/#剧集$/index.php/vod/show/id/27/page/#电影$/index.php/vod/show/id/28/page/#综艺$/index.php/vod/show/id/31/page/", //网站列表的分类
  "houzhui": ".html", //网站翻页链接的后缀

  "shifouercijiequ": "0", //截取的列表数组是否需要二次截取，0不需要，1需要
  "jiequqian": "空", //不需要二次截取就填空
  "jiequhou": "空", //不需要二次截取就填空
  "jiequshuzuqian": "class=\"module-item-pic\"", //截取的列表数组的前关键词,截取的关键词有 " 的用 \ 进行转义
  "jiequshuzuhou": "alt=\"", //截取的列表数组的后关键词,截取的关键词有 " 的用 \ 进行转义
  "tupianqian": "src=\"", //列表中资源的图片前关键词,截取的关键词有 " 的用 \ 进行转义
  "tupianhou": "\"", //列表中资源的图片后关键词,截取的关键词有 " 的用 \ 进行转义
  "biaotiqian": "title=\"", //列表中资源的标题前关键词,截取的关键词有 " 的用 \ 进行转义
  "biaotihou": "\"", //列表中资源的标题后关键词,截取的关键词有 " 的用 \ 进行转义
  "lianjieqian": "href=\"", //列表中资源的详情页跳转链接前关键词,截取的关键词有 " 的用 \ 进行转义
  "lianjiehou": "\"", //列表中资源的详情页跳转链接后关键词,截取的关键词有 " 的用 \ 进行转义

  //搜索部分基本不用动，现在网站基本都是苹果CMS，所有搜索是固定的。
  "sousuoqian": "/index.php/ajax/suggest?mid=1&wd=",
  "sousuohou": "&limit=500",
  "sousuohouzhui": "/index.php/vod/detail/id/", //搜索页影片跳转详情页的中间标识链接部分
  "ssmoshi": "0",
  "sousuoshifouercijiequ": "0",
  "jspic": "pic",
  "jsname": "name",
  "jsid": "id",
  "ssjiequqian": "空",
  "ssjiequhou": "空",
  "ssjiequshuzuqian": "空",
  "ssjiequshuzuhou": "空",
  "sstupianqian": "空",
  "sstupianhou": "空",
  "ssbiaotiqian": "空",
  "ssbiaotihou": "空",
  "sslianjieqian": "空",
  "sslianjiehou": "空",

  "bfshifouercijiequ": "0",
  "bfjiequqian": "空",
  "bfjiequhou": "空",
  "bfjiequshuzuqian": "id=\"sort-item-", //播放截取的列表数组的前关键词
  "bfjiequshuzuhou": "</div>", //播放截取的列表数组的后关键词

  "zhuangtaiqian": "更新：</span>", //状态前关键词
  "zhuangtaihou": "</p>", //状态后关键词
  "daoyanqian": "导演：</span>", //导演前关键词
  "daoyanhou": "</a>", //导演态后关键词
  "zhuyanqian": "主演：</span>", //主演前关键词
  "zhuyanhou": "</a>", //主演后关键词
  "juqingqian": "vod_content\">", //剧情前关键词
  "juqinghou": "<a", //剧情后关键词

  "bfyshifouercijiequ": "0", //截取的播放列表数组是否需要二次截取，0不需要，1需要
  "bfyjiequqian": "空", //不需要二次截取就填空
  "bfyjiequhou": "空", //不需要二次截取就填空
  "bfyjiequshuzuqian": "<a", //播放剧集数组前关键词
  "bfyjiequshuzuhou": "/a>", //播放剧集数组后关键词
  "bfbiaotiqian": "<span>", //播放剧集标题前关键词
  "bfbiaotihou": "</span>", //状播放剧集标题后关键词
  "bflianjieqian": "href=\"", //播放剧集链接前关键词
  "bflianjiehou": "\""
} //播放剧集链接后关键词
