{
  "author": "20220609",
  "name": "看片狂人",
  "url": "https://www.kpkuang.xyz", //填网站链接
  "tihuan": "cnzz.com", //这个不用动，是个别网站嗅探时过滤地址用的
  "User": "空", //这个不用动，是个别网站播放需要请求头时才用到
  "shouye": "1",

  "fenlei": "豆瓣电影$/vodshow/1--douban_score%2Cscore------#豆瓣连续剧$/vodshow/2--douban_score%2Cscore------#豆瓣综艺$/vodshow/3--douban_score%2Cscore------#豆瓣动漫$/vodshow/4--douban_score%2Cscore------#动画片$/vodshow/31--douban_score%2Cscore------#亲子动漫$/vodshow/4---亲子-----#益智动漫$/vodshow/4---益智-----#记录片$/vodshow/29--------#国产剧$/vodshow/13--------#港剧$/vodshow/14--------#日剧$/vodshow/15--------#欧美剧$/vodshow/16--------#韩剧$/vodshow/23--------#越南剧$/vodshow/22--------#泰剧$/vodshow/21--------#台剧$/vodshow/20--------#海外剧$/vodshow/30--------#国产动漫$/vodshow/4-中国大陆-------#日本动漫$/vodshow/4-日本-------#美国动漫$/vodshow/4-美国-------#韩国动漫$/vodshow/4-韩国-------#台湾动漫$/vodshow/4-台湾-------#动作片$/vodshow/6--------#喜剧片$/vodshow/7--------#爱情片$/vodshow/8--------#科幻片$/vodshow/9--------#恐怖片$/vodshow/10--------#剧情片$/vodshow/11--------#战争片$/vodshow/12--------", //网站列表的分类
  "houzhui": "-----.html", //网站翻页链接的后缀

  "shifouercijiequ": "0", //截取的列表数组是否需要二次截取，0不需要，1需要
  "jiequqian": "空", //不需要二次截取就填空
  "jiequhou": "空", //不需要二次截取就填空
  "jiequshuzuqian": "class=\"fed-list-pics", //截取的列表数组的前关键词,截取的关键词有 " 的用 \ 进行转义
  "jiequshuzuhou": "class=\"fed-list-score2", //截取的列表数组的后关键词,截取的关键词有 " 的用 \ 进行转义
  "tupianqian": "data-original=\"", //列表中资源的图片前关键词,截取的关键词有 " 的用 \ 进行转义
  "tupianhou": "\"", //列表中资源的图片后关键词,截取的关键词有 " 的用 \ 进行转义
  "biaotiqian": "title=\"", //列表中资源的标题前关键词,截取的关键词有 " 的用 \ 进行转义
  "biaotihou": "\"", //列表中资源的标题后关键词,截取的关键词有 " 的用 \ 进行转义
  "lianjieqian": "href=\"", //列表中资源的详情页跳转链接前关键词,截取的关键词有 " 的用 \ 进行转义
  "lianjiehou": "\"", //列表中资源的详情页跳转链接后关键词,截取的关键词有 " 的用 \ 进行转义


  //搜索部分基本不用动，现在网站基本都是苹果CMS，所有搜索是固定的。
  "sousuoqian": "/vodsearch/-------------.html?wd=",
  "sousuohou": "&limit=500",
  "sousuohouzhui": "/voddetail/", //搜索页影片跳转详情页的中间标识链接部分
  "ssmoshi": "1",
  "sousuoshifouercijiequ": "0",
  "jspic": "空",
  "jsname": "空",
  "jsid": "空",
  "ssjiequqian": "空",
  "ssjiequhou": "空",
  "ssjiequshuzuqian": "class=\"fed-list-pics",
  "ssjiequshuzuhou": "<span",
  "sstupianqian": "data-original=\"",
  "sstupianhou": "\"",
  "ssbiaotiqian": "title=\"",
  "ssbiaotihou": "\"",
  "sslianjieqian": "href=\"",
  "sslianjiehou": "\"",

  "bfshifouercijiequ": "0",
  "bfjiequqian": "空",
  "bfjiequhou": "空",
  "bfjiequshuzuqian": "</ul><ul class=\"fed-part-rows\"", //播放截取的列表数组的前关键词
  "bfjiequshuzuhou": "</ul>", //播放截取的列表数组的后关键词

  "zhuangtaiqian": "<p>最近更新:", //状态前关键词
  "zhuangtaihou": "</p>", //状态后关键词
  "daoyanqian": "导演：</span>", //导演前关键词
  "daoyanhou": "</li>", //导演态后关键词
  "zhuyanqian": "主演：</span>", //主演前关键词
  "zhuyanhou": "</li>", //主演后关键词
  "juqingqian": "简介：</span>看片狂人(www.kpkuang.com)为您奉上", //剧情前关键词
  "juqinghou": "<span", //剧情后关键词

  "bfyshifouercijiequ": "0", //截取的播放列表数组是否需要二次截取，0不需要，1需要
  "bfyjiequqian": "空", //不需要二次截取就填空
  "bfyjiequhou": "空", //不需要二次截取就填空
  "bfyjiequshuzuqian": "<a", //播放剧集数组前关键词
  "bfyjiequshuzuhou": "/a>", //播放剧集数组后关键词
  "bfbiaotiqian": ">", //播放剧集标题前关键词
  "bfbiaotihou": "<", //状播放剧集标题后关键词
  "bflianjieqian": "href=\"", //播放剧集链接前关键词
  "bflianjiehou": "\""
} //播放剧集链接后关键词
