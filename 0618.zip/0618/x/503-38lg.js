{
    "ua": "",
    "homeUrl": "https://348z.com",
    "dcVipFlag": "true",
    "pCfgJs": "https://348z.com/static/js/playerconfig.js",
    "pCfgJsR": "[\\W|\\S|.]*?MacPlayerConfig.player_list[\\W|\\S|.]*?=([\\W|\\S|.]*?),MacPlayerConfig.downer_list",
    "dcShow2Vip": {},
    "dcPlayUrl": "true",
    "cateNode": "//div[contains(@class,'ecnav-nav')]/div[contains(@class, 'nav-channel')]/a[contains(@href, 'vodtype')",
    "cateName": "/text()",
    "cateId": "/@href",
    "cateIdR": "/vodtype/(\\d+).html",
    "cateManual": {
        "电影": "1",
        "连续剧": "2",
        "综艺": "3",
        "动漫": "4",
        "4K专区": "37"
    },
    "homeVodNode": "//div[contains(@class, 'vodlist hotgrow') and @id='hot1']//a[@class='aplus-exp ecimgbor']",
    "homeVodName": "/@title",
    "homeVodId": "/@href",
    "homeVodIdR": "/voddetail/(\\w+).html",
    "homeVodImg": "/div/@data-original",
    "homeVodImgR": "\\S+(http\\S+)",
    "homeVodMark": "/span[@class='pack-prb hidden']/text()",
    "cateUrl": "https://348z.com/vodshow/area/{area}/id/{cateId}/page/{catePg}/year/{year}.html",
    "cateVodNode": "//div[contains(@class, 'vodlist hotgrow')]//a[@class='aplus-exp ecimgbor']",
    "cateVodName": "/@title",
    "cateVodId": "/@href",
    "cateVodIdR": "/voddetail/(\\w+).html",
    "cateVodImg": "/div/@data-original",
    "cateVodImgR": "\\S+(http\\S+)",
    "cateVodMark": "/span[@class='pack-prb hidden']/text()",
    "dtUrl": "https://348z.com/voddetail/{vid}.html",
    "dtNode": "//body",
    "dtName": "//div[@class='s-top-info-title cf wow fadeInDownBig']/h1/text()",
    "dtNameR": "",
    "dtImg": "//div[@class='s-cover box']/a/img/@src",
    "dtImgR": "\\S+(http\\S+)",
    "dtCate": "//span[contains(text(), '分类')]/following-sibling::*/text()",
    "dtCateR": "",
    "dtArea": "//span[contains(text(), '地区')]/following-sibling::*/text()",
    "dtAreaR": "",
    "dtYear": "//span[contains(text(), '年份')]/following-sibling::*/text()",
    "dtYearR": "",
    "dtMark": "//span[contains(text(), '更新')]/following-sibling::*/text()",
    "dtMarkR": "",
    "dtActor": "//span[contains(text(), '主演')]/following-sibling::*/text()",
    "dtActorR": "",
    "dtDirector": "//span[contains(text(), '导演')]/following-sibling::*/text()",
    "dtDirectorR": "",
    "dtDesc": "//span[contains(@id, 'cText')]/text()",
    "dtDescR": "",
    "dtFromNode": "//a[contains(@class, 'channelname swiper-slide')]",
    "dtFromName": "/text()",
    "dtFromNameR": "",
    "dtUrlNode": "//div[contains(@id, 'playsx')]//ul[contains(@class,'content_playlist')]",
    "dtUrlSubNode": "/li/a",
    "dtUrlId": "@href",
    "dtUrlIdR": "/vodplay/(\\S+).html",
    "dtUrlName": "/text()",
    "dtUrlNameR": "",
    "playUrl": "https://348z.com/vodplay/{playUrl}.html",
    "playUa": "",
    "searchUrl": "https://348z.com/index.php/ajax/suggest?mid=1&wd={wd}&limit=10",
    "scVodNode": "json:list",
    "scVodName": "name",
    "scVodId": "id",
    "scVodIdR": "",
    "scVodImg": "pic",
    "scVodMark": "",
  "filter": {
    "37": [
      {
        "key": "cateId",
        "name": "分类",
        "value": [
          {"n": "全部","v": ""},
          {"n": "4K电影","v": "38"},
          {"n": "4K电视剧","v": "39"}
        ]
      },
      {
        "key": "area",
        "name": "地区",
        "value": [
          {"n": "全部","v": ""},
          {"n": "大陆","v": "大陆"},
          {"n": "香港","v": "香港"},
          {"n": "台湾","v": "台湾"},
          {"n": "美国","v": "美国"},
          {"n": "法国","v": "法国"},
          {"n": "英国","v": "英国"},
          {"n": "日本","v": "日本"},
          {"n": "韩国","v": "韩国"},
          {"n": "德国","v": "德国"},
          {"n": "泰国","v": "泰国"},
          {"n": "印度","v": "印度"},
          {"n": "意大利","v": "意大利"},
          {"n": "西班牙","v": "西班牙"},
          {"n": "加拿大","v": "加拿大"},
          {"n": "其他","v": "其他"}
        ]
      },
      {
        "key": "year",
        "name": "年份",
        "value": [
          {"n": "全部","v": ""},
          {"n": "2022","v": "2022"},
          {"n": "2021","v": "2021"},
          {"n": "2020","v": "2020"},
          {"n": "2019","v": "2019"},
          {"n": "2018","v": "2018"},
          {"n": "2017","v": "2017"},
          {"n": "2016","v": "2016"},
          {"n": "2015","v": "2015"},
          {"n": "2014","v": "2014"},
          {"n": "2013","v": "2013"},
          {"n": "2012","v": "2012"},
          {"n": "2011","v": "2011"},
          {"n": "2010","v": "2010"}
        ]
      }
    ],
    "1": [
      {
        "key": "cateId",
        "name": "分类",
        "value": [
          {"n": "全部","v": "1"},
          {"n": "动作片","v": "6"},
          {"n": "喜剧片","v": "7"},
          {"n": "爱情片","v": "8"},
          {"n": "科幻片","v": "9"},
          {"n": "恐怖片","v": "10"},
          {"n": "剧情片","v": "11"},
          {"n": "战争片","v": "12"},
          {"n": "纪录片","v": "20"},
          {"n": "灾难片","v": "21"},
          {"n": "魔幻片","v": "22"},
          {"n": "青春片","v": "23"},
          {"n": "犯罪片","v": "24"},
          {"n": "悬疑片","v": "25"},
          {"n": "微电影","v": "26"},
          {"n": "音乐片","v": "27"},
          {"n": "B站电影","v": "29"}
        ]
      },
      {
        "key": "area",
        "name": "地区",
        "value": [
          {"n": "全部","v": ""},
          {"n": "大陆","v": "大陆"},
          {"n": "香港","v": "香港"},
          {"n": "台湾","v": "台湾"},
          {"n": "美国","v": "美国"},
          {"n": "法国","v": "法国"},
          {"n": "英国","v": "英国"},
          {"n": "日本","v": "日本"},
          {"n": "韩国","v": "韩国"},
          {"n": "德国","v": "德国"},
          {"n": "泰国","v": "泰国"},
          {"n": "印度","v": "印度"},
          {"n": "意大利","v": "意大利"},
          {"n": "西班牙","v": "西班牙"},
          {"n": "加拿大","v": "加拿大"},
          {"n": "其他","v": "其他"}
        ]
      },
      {
        "key": "year",
        "name": "年份",
        "value": [
          {"n": "全部","v": ""},
          {"n": "2022","v": "2022"},
          {"n": "2021","v": "2021"},
          {"n": "2020","v": "2020"},
          {"n": "2019","v": "2019"},
          {"n": "2018","v": "2018"},
          {"n": "2017","v": "2017"},
          {"n": "2016","v": "2016"},
          {"n": "2015","v": "2015"},
          {"n": "2014","v": "2014"},
          {"n": "2013","v": "2013"},
          {"n": "2012","v": "2012"},
          {"n": "2011","v": "2011"},
          {"n": "2010","v": "2010"}
        ]
      }
    ],
    "2": [
      {
        "key": "cateId",
        "name": "分类",
        "value": [
          {"n": "全部","v": ""},
          {"n": "国产剧","v": "13"},
          {"n": "港台剧","v": "14"},
          {"n": "日韩剧","v": "15"},
          {"n": "欧美剧","v": "16"},
          {"n": "B站剧集","v": "49"},
          {"n": "其他剧","v": "50"}
        ]
      },
      {
        "key": "area",
        "name": "地区",
        "value": [
          {"n": "全部","v": ""},
          {"n": "内地","v": "内地"},
          {"n": "韩国","v": "韩国"},
          {"n": "香港","v": "香港"},
          {"n": "台湾","v": "台湾"},
          {"n": "日本","v": "日本"},
          {"n": "美国","v": "美国"},
          {"n": "泰国","v": "泰国"},
          {"n": "英国","v": "英国"},
          {"n": "新加坡","v": "新加坡"},
          {"n": "其他","v": "其他"}
        ]
      },
      {
        "key": "year",
        "name": "年份",
        "value": [
          {"n": "全部","v": ""},
          {"n": "2022","v": "2022"},
          {"n": "2021","v": "2021"},
          {"n": "2020","v": "2020"},
          {"n": "2019","v": "2019"},
          {"n": "2018","v": "2018"},
          {"n": "2017","v": "2017"},
          {"n": "2016","v": "2016"},
          {"n": "2015","v": "2015"},
          {"n": "2014","v": "2014"},
          {"n": "2013","v": "2013"},
          {"n": "2012","v": "2012"},
          {"n": "2011","v": "2011"},
          {"n": "2010","v": "2010"}
        ]
      }
    ],
    "3": [
      {
        "key": "area",
        "name": "地区",
        "value": [
          {"n": "全部","v": ""},
          {"n": "内地","v": "内地"},
          {"n": "港台","v": "港台"},
          {"n": "日韩","v": "日韩"},
          {"n": "欧美","v": "欧美"}
        ]
      },
      {
        "key": "year",
        "name": "年份",
        "value": [
          {"n": "全部","v": ""},
          {"n": "2022","v": "2022"},
          {"n": "2021","v": "2021"},
          {"n": "2020","v": "2020"},
          {"n": "2019","v": "2019"},
          {"n": "2018","v": "2018"},
          {"n": "2017","v": "2017"},
          {"n": "2016","v": "2016"},
          {"n": "2015","v": "2015"},
          {"n": "2014","v": "2014"},
          {"n": "2013","v": "2013"},
          {"n": "2012","v": "2012"},
          {"n": "2011","v": "2011"},
          {"n": "2010","v": "2010"}
        ]
      }
    ],
    "4": [
      {
        "key": "area",
        "name": "地区",
        "value": [
          {"n": "全部","v": ""},
          {"n": "国产","v": "国产"},
          {"n": "日本","v": "日本"},
          {"n": "欧美","v": "欧美"},
          {"n": "其他","v": "其他"}
        ]
      },
      {
        "key": "year",
        "name": "年份",
        "value": [
          {"n": "全部","v": ""},
          {"n": "2022","v": "2022"},
          {"n": "2021","v": "2021"},
          {"n": "2020","v": "2020"},
          {"n": "2019","v": "2019"},
          {"n": "2018","v": "2018"},
          {"n": "2017","v": "2017"},
          {"n": "2016","v": "2016"},
          {"n": "2015","v": "2015"},
          {"n": "2014","v": "2014"},
          {"n": "2013","v": "2013"},
          {"n": "2012","v": "2012"},
          {"n": "2011","v": "2011"},
          {"n": "2010","v": "2010"}
        ]
      }
    ]
  }
}
