{
    "author":"Tangsan99999",
    "ua": "",
    "homeUrl": "https://www.lranc.com",
    "dcVipFlag": "true",
    "dcPlayUrl": "true",
    "cateNode": "//ul[contains(@class,'stui-header__menu')]/li[contains(@class, 'dropdown-hover')]//div/ul/li/a[contains(@href, 'ystv') and not(contains(@href,'label'))]",
    "cateName": "/text()",
    "cateId": "/@href",
    "cateIdR": "/ystv/(\\S+).html",
    "cateManual": {
        "电影": "dydq",
        "电视剧": "dsjdq",
        "综艺": "zydq",
        "动漫": "dmdq",
        "纪录片": "jlpdq"
    },
    "homeVodNode": "//div[contains(@class, 'padding-0')]//ul[contains(@class,'stui-vodlist')]/li//a[contains(@class,'stui-vodlist__thumb')]",
    "homeVodName": "/@title",
    "homeVodId": "/@href",
    "homeVodIdR": "/zxgk/(\\w+).html",
    "homeVodImg": "/@data-original",
    "homeVodImgR": "\\S+(http\\S+)",
    "homeVodMark": "/span[contains(@class,'pic-text')]/text()",
    "cateUrl": "https://www.lranc.com/phb/{cateId}/by/{by}/page/{catePg}/year/{year}.html",
    "cateVodNode": "//ul[contains(@class,'stui-vodlist')]//li//a[contains(@class,'stui-vodlist__thumb')]",
    "cateVodName": "/@title",
    "cateVodId": "/@href",
    "cateVodIdR": "/zxgk/(\\w+).html",
    "cateVodImg": "/@data-original",
    "cateVodImgR": "\\S+(http\\S+)",
    "cateVodMark": "/span[contains(@class,'pic-text')]/text()",
    "dtUrl": "https://www.lranc.com/zxgk/{vid}.html",
    "dtNode": "//body",
    "dtName": "//a[contains(@class,'stui-vodlist__thumb')]/@title",
    "dtNameR": "",
    "dtImg": "//a[contains(@class,'stui-vodlist__thumb')]/img/@data-original",
    "dtImgR": "\\S+(http\\S+)",
    "dtCate": "//span[contains(@class,'text-muted') and contains(text(), '类型')]/following-sibling::*/text()",
    "dtCateR": "",
    "dtArea": "//span[contains(@class,'text-muted') and contains(text(), '地区')]/following-sibling::*/text()",
    "dtAreaR": "",
    "dtYear": "//span[contains(@class,'text-muted') and contains(text(), '年份')]/following-sibling::*/text()",
    "dtYearR": "",
    "dtActor": "//span[contains(@class,'text-muted') and contains(text(), '主演')]/following-sibling::*/text()",
    "dtActorR": "",
    "dtDirector": "//span[contains(@class,'text-muted') and contains(text(), '导演')]/following-sibling::*/text()",
    "dtDirectorR": "",
    "dtMark": "//span[contains(@class,'text-muted') and contains(text(), '更新')]/following-sibling::*/text()",
    "dtMarkR": "",
    "dtDesc": "//p[@class='col-pd']/text()",
    "dtDescR": "",
    "dtFromNode": "//div[@class='stui-pannel-box b playlist mb']//h3(@class,'title')",
    "dtFromName": "/text()",
    "dtFromNameR": "",
    "dtUrlNode": "//div[@class='stui-pannel_bd col-pd clearfix']/ul[contains(@class, 'stui-content__playlist column8 clearfix')]",
    "dtUrlSubNode": "/li/a",
    "dtUrlId": "@href",
    "dtUrlIdR": "/zxbf/(\\S+).html",
    "dtUrlName": "/text()",
    "dtUrlNameR": "",
    "playUrl": "https://www.lranc.com/zxbf/{playUrl}.html",
    "playUa": "",
    "searchUrl": "https://www.lranc.com/index.php/ajax/suggest?mid=1&wd={wd}&limit=10",
    "scVodNode": "json:list",
    "scVodName": "name",
    "scVodId": "id",
    "scVodIdR": "",
    "scVodImg": "pic",
    "scVodMark": "",
 "filter": {
    "dydq": [
      {
        "key": "cateId",
        "name": "分类",
        "value": [
          {"n": "全部","v": ""},
          {"n": "劇情片","v": "jqpdq"},
          {"n": "動作片","v": "dzpdq"},
          {"n": "科幻片","v": "khpdq"},
          {"n": "喜劇片","v": "xjpdq"},
          {"n": "愛情片","v": "aqpdq"},
          {"n": "戰爭片","v": "zzpdq"},
          {"n": "恐怖片","v": "kbpdq"}
        ]
      },
      {
        "key": "area",
        "name": "地区",
        "value": [
          {"n": "全部","v": ""},
          {"n": "美国","v": "美国"},
          {"n": "台湾","v": "台湾"},
          {"n": "大陆","v": "大陆"},
          {"n": "法国","v": "法国"},
          {"n": "英国","v": "英国"},
          {"n": "香港","v": "香港"},
          {"n": "日本","v": "日本"},
          {"n": "韩国","v": "韩国"},
          {"n": "泰国","v": "泰国"},
          {"n": "西班牙","v": "西班牙"},
          {"n": "其他","v": "其他"}
        ]
      },
      {
        "key": "year",
        "name": "年份",
        "value": [
          {"n": "全部","v": ""},
          {"n": "2022","v": "2022"},
          {"n": "2021","v": "2021"},
          {"n": "2020","v": "2020"},
          {"n": "2019","v": "2019"},
          {"n": "2018","v": "2018"},
          {"n": "2017","v": "2017"},
          {"n": "2016","v": "2016"},
          {"n": "2015","v": "2015"},
          {"n": "2014","v": "2014"},
          {"n": "2013","v": "2013"},
          {"n": "2012","v": "2012"}
        ]
      },
      {
        "key": "by",
        "name": "排序",
        "value": [
          {"n": "按更新","v": "time"},
          {"n": "周人气","v": "hits"},
          {"n": "月人气","v": "score"}
        ]
      }
    ],
    "dsjdq": [
      {
        "key": "cateId",
        "name": "分类",
        "value": [
          {"n": "全部","v": ""},
          {"n": "国产剧","v": "gcjdq"},
          {"n": "香港剧","v": "xgjdq"},
          {"n": "台湾剧","v": "twjdq"},
          {"n": "韩国剧","v": "hgjdq"},
          {"n": "日本剧","v": "rbjdq"},
          {"n": "海外剧","v": "hwjdq"},
          {"n": "美国剧","v": "美国"},
          {"n": "新加坡剧","v": "新加坡"},
          {"n": "泰国剧","v": "泰国"},
          {"n": "英国剧","v": "英国"}
        ]
      },
      {
        "key": "year",
        "name": "年份",
        "value": [
          {"n": "全部","v": ""},
          {"n": "2022","v": "2022"},
          {"n": "2021","v": "2021"},
          {"n": "2020","v": "2020"},
          {"n": "2019","v": "2019"},
          {"n": "2018","v": "2018"},
          {"n": "2017","v": "2017"},
          {"n": "2016","v": "2016"},
          {"n": "2015","v": "2015"},
          {"n": "2014","v": "2014"},
          {"n": "2013","v": "2013"},
          {"n": "2012","v": "2012"}
        ]
      },
      {
        "key": "by",
        "name": "排序",
        "value": [
          {"n": "按更新","v": "time"},
          {"n": "周人气","v": "hits"},
          {"n": "月人气","v": "score"}
        ]
      }
    ],
    "dmdq": [
      {
        "key": "area",
        "name": "地区",
        "value": [
          {"n": "全部","v": ""},
          {"n": "大陆","v": "大陆"},
          {"n": "日本","v": "日本"},
          {"n": "美国","v": "美国"},
          {"n": "香港","v": "香港"}
        ]
      },
      {
        "key": "year",
        "name": "年份",
        "value": [
          {"n": "全部","v": ""},
          {"n": "2022","v": "2022"},
          {"n": "2021","v": "2021"},
          {"n": "2020","v": "2020"},
          {"n": "2019","v": "2019"},
          {"n": "2018","v": "2018"},
          {"n": "2017","v": "2017"},
          {"n": "2016","v": "2016"},
          {"n": "2015","v": "2015"},
          {"n": "2014","v": "2014"},
          {"n": "2013","v": "2013"},
          {"n": "2012","v": "2012"}
        ]
      },
      {
        "key": "by",
        "name": "排序",
        "value": [
          {"n": "按更新","v": "time"},
          {"n": "周人气","v": "hits"},
          {"n": "月人气","v": "score"}
        ]
      }
    ],
    "zydq": [
      {
        "key": "area",
        "name": "地区",
        "value": [
          {"n": "全部","v": ""},
          {"n": "大陆","v": "大陆"},
          {"n": "台湾","v": "台湾"},
          {"n": "香港","v": "香港"},
          {"n": "日本","v": "日本"},
          {"n": "美国","v": "美国"},
          {"n": "英国","v": "英国"}
        ]
      },
      {
        "key": "year",
        "name": "年份",
        "value": [
          {"n": "全部","v": ""},
          {"n": "2022","v": "2022"},
          {"n": "2021","v": "2021"},
          {"n": "2020","v": "2020"},
          {"n": "2019","v": "2019"},
          {"n": "2018","v": "2018"},
          {"n": "2017","v": "2017"},
          {"n": "2016","v": "2016"},
          {"n": "2015","v": "2015"},
          {"n": "2014","v": "2014"},
          {"n": "2013","v": "2013"},
          {"n": "2012","v": "2012"}
        ]
      },
      {
        "key": "by",
        "name": "排序",
        "value": [
          {"n": "按更新","v": "time"},
          {"n": "周人气","v": "hits"},
          {"n": "月人气","v": "score"}
        ]
      }
    ],
    "jlpdq": [
      {
        "key": "year",
        "name": "年份",
        "value": [
          {"n": "全部","v": ""},
          {"n": "2022","v": "2022"},
          {"n": "2021","v": "2021"},
          {"n": "2020","v": "2020"},
          {"n": "2019","v": "2019"},
          {"n": "2018","v": "2018"},
          {"n": "2017","v": "2017"},
          {"n": "2016","v": "2016"},
          {"n": "2015","v": "2015"},
          {"n": "2014","v": "2014"},
          {"n": "2013","v": "2013"},
          {"n": "2012","v": "2012"}
        ]
      },
      {
        "key": "by",
        "name": "排序",
        "value": [
          {"n": "按更新","v": "time"},
          {"n": "周人气","v": "hits"},
          {"n": "月人气","v": "score"}
        ]
      }
    ]
  }
}
